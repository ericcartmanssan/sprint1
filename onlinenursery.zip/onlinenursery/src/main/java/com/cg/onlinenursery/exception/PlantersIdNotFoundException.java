package com.cg.onlinenursery.exception;

public class PlantersIdNotFoundException extends RuntimeException{

	public PlantersIdNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PlantersIdNotFoundException [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
	 