package com.cg.onlinenursery.exception;

public class AdminExistsException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	//	public AdminExistsException(String msg) {
//		// TODO Auto-generated constructor stub
//		super(msg);
//	}
}