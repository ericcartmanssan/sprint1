package com.cg.onlinenursery.exception;

public class PlantsIdNotFoundException extends Exception {

	public PlantsIdNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	public PlantsIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
