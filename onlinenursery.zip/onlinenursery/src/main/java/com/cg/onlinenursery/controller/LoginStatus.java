package com.cg.onlinenursery.controller;

public enum LoginStatus {
	LOGGEDIN;

}