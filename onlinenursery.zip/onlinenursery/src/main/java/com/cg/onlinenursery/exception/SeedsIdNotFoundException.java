package com.cg.onlinenursery.exception;

public class SeedsIdNotFoundException extends Exception {

	public SeedsIdNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	public SeedsIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
  